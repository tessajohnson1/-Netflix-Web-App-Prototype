import { create } from "zustand";

export const useMovieStore = create((set) => ({
  movies: [],
  hoveredMovie: null,
  playingMovie: null,

  setMovies: (movies) => set({ movies }),

  hoverMovie: (movie) => set({ hoveredMovie: movie }),
  clearHover: () => set({ hoveredMovie: null }),

  playMovie: (movie) => set({ playingMovie: movie }),
  stopMovie: () => set({ playingMovie: null }),
}));
