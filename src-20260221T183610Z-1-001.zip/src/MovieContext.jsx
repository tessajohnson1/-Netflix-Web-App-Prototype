import { createContext, useContext, useState } from "react";

const MovieContext = createContext();

export const useMovieContext = () => useContext(MovieContext);

export const MovieProvider = ({ children }) => {
  const [movies, setMovies] = useState([]);
  const [hoveredMovie, setHoveredMovie] = useState(null);
  const [playingMovie, setPlayingMovie] = useState(null);

  const hoverMovie = (movie) => setHoveredMovie(movie);
  const clearHover = () => setHoveredMovie(null);

  const playMovie = (movie) => setPlayingMovie(movie);
  const stopMovie = () => setPlayingMovie(null);

  return (
    <MovieContext.Provider
      value={{
        movies,
        setMovies,
        hoveredMovie,
        hoverMovie,
        clearHover,
        playingMovie,
        playMovie,
        stopMovie,
      }}
    >
      {children}
    </MovieContext.Provider>
  );
};
