import { useEffect } from "react";
import MovieCard from "./components/MovieCard";
import BackgroundPreview from "./components/BackgroundPreview";
import PlayerOverlay from "./components/PlayerOverlay";
import { useMovieStore } from "./store/useMovieStore";

const mockMovies = [
  {
    id: 1,
    name: "Big Buck Bunny",
    poster: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/Camponotus_flavomarginatus_ant.jpg/320px-Camponotus_flavomarginatus_ant.jpg",
    // Use Google's well-known public test MP4 — always up, no CORS issues
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
  },
{
  id: 2,
  name: "Elephant Dream",
  poster: "https://picsum.photos/seed/elephant/400/600",
  streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
},
  {
    id: 3,
    name: "For Bigger Blazes",
    poster: "https://picsum.photos/seed/blazes/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  },
  {
    id: 4,
    name: "For Bigger Escapes",
    poster: "https://picsum.photos/seed/escapes/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  },
  {
    id: 5,
    name: "For Bigger Fun",
    poster: "https://picsum.photos/seed/fun42/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
  },
  {
    id: 6,
    name: "For Bigger Joyrides",
    poster: "https://picsum.photos/seed/joyride/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
  },
  {
    id: 7,
    name: "For Bigger Meltdowns",
    poster: "https://picsum.photos/seed/meltdown/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
  },
  {
    id: 8,
    name: "Subaru Outback",
    poster: "https://picsum.photos/seed/subaru/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
  },
  {
    id: 9,
    name: "Volkswagen GTI",
    poster: "https://picsum.photos/seed/vwgti/400/600",
    streamUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
  },
];

export default function App() {
  const { movies, setMovies } = useMovieStore();

  useEffect(() => {
    setMovies(mockMovies);
  }, []);

  return (
    <div className="min-h-screen p-6 relative">
      <h1 className="text-3xl font-bold mb-6 text-center">Netflix Prototype</h1>
      <BackgroundPreview />
      <PlayerOverlay />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {movies.map((m) => (
          <MovieCard key={m.id} movie={m} />
        ))}
      </div>
    </div>
  );
}