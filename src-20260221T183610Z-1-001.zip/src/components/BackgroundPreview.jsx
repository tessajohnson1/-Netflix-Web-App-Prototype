import React, { useEffect, useRef } from "react";
import { useMovieStore } from "../store/useMovieStore";

export default function BackgroundPreview() {
  const hoveredMovie = useMovieStore((s) => s.hoveredMovie);
  const videoRef = useRef(null);

  useEffect(() => {
    if (!videoRef.current) return;

    if (hoveredMovie) {
      videoRef.current.src = hoveredMovie.streamUrl;
      videoRef.current
        .play()
        .catch(() => {
          videoRef.current.muted = true;
          videoRef.current.play();
        });
    } else {
      videoRef.current.pause();
      videoRef.current.src = "";
    }
  }, [hoveredMovie]);

  return (
    <video
      ref={videoRef}
      className="fixed inset-0 -z-10 opacity-40 object-cover w-full h-full pointer-events-none"
      muted
      loop
      playsInline
    />
  );
}
