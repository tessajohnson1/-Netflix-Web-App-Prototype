import { useEffect, useRef, useState } from "react";
import { useMovieStore } from "../store/useMovieStore";

export default function PlayerOverlay() {
  const { playingMovie, stopMovie } = useMovieStore();
  const videoRef = useRef(null);
  const [showBack, setShowBack] = useState(false);

  // Show back button on mouse move
  useEffect(() => {
    const handleMove = () => {
      setShowBack(true);
      setTimeout(() => setShowBack(false), 2000);
    };
    window.addEventListener("mousemove", handleMove);
    return () => window.removeEventListener("mousemove", handleMove);
  }, []);

  // Play video whenever playingMovie changes
  useEffect(() => {
    if (playingMovie && videoRef.current) {
      videoRef.current.src = playingMovie.streamUrl;
      videoRef.current.muted = false; // can toggle unmute later
      videoRef.current.play().catch(() => {
        // fallback if autoplay blocked
        videoRef.current.muted = true;
        videoRef.current.play();
      });
    } else if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.src = "";
    }
  }, [playingMovie]);

  if (!playingMovie) return null;

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      {showBack && (
        <button
          className="absolute top-4 left-4 bg-white/20 backdrop-blur px-4 py-2 rounded-lg z-50"
          onClick={stopMovie}
        >
          ← Back
        </button>
      )}

      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        controls
        autoPlay
        playsInline
      />
    </div>
  );
}
