import { useMovieStore } from "../store/useMovieStore";

export default function MovieCard({ movie }) {
  const { hoverMovie, clearHover, playMovie } = useMovieStore();

  return (
    <div
      className="cursor-pointer transform hover:scale-105 transition duration-300"
      onMouseEnter={() => hoverMovie(movie)}
      onMouseLeave={clearHover}
      onClick={() => playMovie(movie)}
    >
      <img
        src={movie.poster}
        alt={movie.name}
        className="rounded-xl w-full h-64 object-cover shadow-lg"
      />
      <p className="mt-2 font-bold text-center">{movie.name}</p>
    </div>
  );
}
